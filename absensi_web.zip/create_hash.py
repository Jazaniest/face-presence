from auth import get_password_hash

hashed_password = get_password_hash("admin123")

print(hashed_password) 